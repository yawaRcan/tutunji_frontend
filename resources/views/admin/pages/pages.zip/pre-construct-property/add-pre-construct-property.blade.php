@extends('admin.layouts.master')
<!-- title -->
@section('title')
    <title> Add Pre-construct Property </title>
@endsection
<!-- media-button-style -->
@section('media-button-style')
    <style>
        .fileUpload {
            position: relative;
            overflow: hidden;
            margin: 10px;
        }
        .fileUpload input.upload {
            position: absolute;
            top: 0;
            right: 0;
            margin: 0;
            padding: 0;
            font-size: 20px;
            cursor: pointer;
            opacity: 0;
            filter: alpha(opacity=0);
        }
    </style>
@endsection
@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Add Pre-construct Property</h1>
                    </div>
{{--                    <div class="col-sm-6">--}}
{{--                        <ol class="breadcrumb float-sm-right">--}}
{{--                            <li class="breadcrumb-item"><a href=""></a>Properties</li>--}}
{{--                            <li class="breadcrumb-item"><a href="#">Pre-construct</a></li>--}}
{{--                        </ol>--}}
{{--                    </div>--}}
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header" style="background-color: #1ED65f">
                                <h3 class="card-title">Add Pre-construct Property</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form action="{{url('/admin/add-pre-construct-property')}}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="card-body">
                                    <!-- validation-error message -->
                                    @if($errors->any())
                                        <div class="alert alert-danger">
                                            <p><strong>Opps Something went wrong</strong></p>
                                            <ul id="error_list">
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @endif
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Title<span style="color: red;">*</span></label>
                                                <input type="text" name="title" class="form-control" value="{{old('title')}}" placeholder="Enter title" maxlength="20" autofocus>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="">Description<span style="color: red;">*</span></label>
                                                {{--<input type="text" name="t_description" class="form-control">--}}
                                                <textarea name="description" id="description" class="form-control" placeholder="Enter description">{{old('description')}}</textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Price in $ (only numbers)</label>
                                                <input type="text" name="price" class="form-control" placeholder="Enter price" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="bmd-label-floating">After Price Label (ex: "/month ")</label>
                                                        <input type="text" name="after_price_label" class="form-control" placeholder="Enter after price label" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label class="bmd-label-floating">Before Price Label (ex: "from ")</label>
                                                        <input type="text" name="before_price_label" class="form-control" placeholder="Enter before price label" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating" for="category-dropdown">Category</label>
                                                <select class="form-control" name="category" id="category-dropdown">
                                                    <option value="">Select Category</option>
                                                    <option value="">None</option>
                                                    <option value="apartment">Apartment</option>
                                                    <option value="condos">Condos</option>
                                                    <option value="duplexes">Duplexes</option>
                                                    <option value="houses">Houses</option>
                                                    <option value="industrial">Industrial</option>
                                                    <option value="land">Land</option>
                                                    <option value="officer">Officer</option>
                                                    <option value="retails">Retails</option>
                                                    <option value="villas">Villas</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating" for="dropdown">Listed In </label>
                                                <select class="form-control" name="listed_in" id="dropdown">
                                                    <option>Select Listed In</option>
                                                    <option value="">None</option>
                                                    <option value="rentals">Rentals</option>
                                                    <option value="sales">sales</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <!-- success-message -->
                                            <div id="file_upload_message" style="padding-left: 12px;color: #1ED65f;"></div>
                                            <!-- error-message -->
                                            <div id="file_upload_error" style="padding-left: 12px;color: red;"></div>
                                            <!-- delete-message -->
                                            <div id="file_upload_delete" style="padding-left: 12px;color: #1ED65f;"></div>
                                            <div class="fileUpload btn btn-success" style="background-color: #1ED65F;border-color: #1ED65F;">
                                                <span>SELECT MEDIA</span>
                                                <input id="mediaBtn" name="media_name" type="file" class="upload">
                                            </div>

                                            <br>
                                            {{-- @foreach($propertyMedia->media_name as $name)--}}
                                            @if(Session::get('media_name'))
                                                <div class="row">
                                                    @foreach(Session::get('media_name') as $key => $image_rows)
                                                        <input type="hidden" id="session_key_{{ $image_rows['id'] }}" value="{{ $key }}">
                                                        <div id="img-remove_{{ $image_rows['id'] }}">
                                                            @if($image_rows['type'] == 'image')
                                                                <img src="{{asset('admin-panel/assets/property-images/media-file/pre-construct/'.$image_rows['name'])}}" height="100px" width="100px" style="margin-left: 27px;" id="del_img_{{ $image_rows['id'] }}">
                                                            @else
                                                                <img src="{{asset('pdf-icon/pdf-logo.png')}}" height="100px" width="100px" style="margin-left: 27px;" id="del_img_{{ $image_rows['id'] }}">
                                                            @endif
                                                            <br>
                                                            <button class="btn btn-danger btn-sm" id="delete_btn" data-id="{{ $image_rows['id'] }}" style="margin-top: 10px;margin-left: 57px;"><i class="fa fa-trash"></i></button>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            @endif
                                        </div>
                                        <!-- image-preview -->
                                        <div class="row" id="image_preview" style="padding-left: 27px;"></div>
                                        {{--<img id="imagePreview" width="100" height="100" />--}}
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <p style="color: grey"><span style="color: red">*</span> At least 1 image is required for a valid submission.Minimum size is 500/500px.</p>
                                                <p style="color: grey">** Double click on the image to select featured.</p>
                                                <p style="color: grey">*** Change images order with Drag & Drop.</p>
                                                <p style="color: grey">**** PDF files upload supported as well.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Floor Plan</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="text-center" style="border: 1px solid lightgrey;padding: 20px;">
                                                <h2>2D</h2>
                                                <div class="fileUpload btn btn-success" style="background-color: #1ED65F;border-color: #1ED65F;">
                                                    <span>CHOOSE FILE</span>
                                                    <input id="btnFloor2D" type="file" class="upload" name="btnFloor2D" onchange="showPreview(event);">
                                                </div>
                                            </div>
                                            <div class="img2D text-center" style="border: 1px solid lightgrey;display: none;margin-top: 2px;padding: 10px;">
                                                <img id="btnFloor2D-preview" height="150px">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="text-center" style="border: 1px solid lightgrey;padding: 20px;">
                                                <h2>3D</h2>
                                                <div class="fileUpload btn btn-success" style="background-color: #1ED65F;border-color: #1ED65F;">
                                                    <span>CHOOSE FILE</span>
                                                    <input id="btnFloor3D" type="file" class="upload" name="btnFloor3D" onchange="showPreview2(event);">
                                                </div>
                                            </div>
                                            <div class="img3D text-center" style="border: 1px solid lightgrey;display: none;margin-top: 2px;padding: 10px;">
                                                <img id="btnFloor3D-preview" height="150px">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" style="margin-top: 10px">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Address<span style="color: red;">*</span></label>
                                                <input type="text" name="address" class="form-control" placeholder="Enter Address" value="{{old('address')}}">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="Country" class="bmd-label-floating">Country</label>
                                                <select class="form-control" name="country" id="country-dropdown">
                                                    <option value="">Select Country</option>
                                                    @foreach ($countries as $country)
                                                        <option value="{{$country->id}}">
                                                            {{$country->name}}
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="state" class="bmd-label-floating">State/Province</label>
                                                <select class="form-control" name="state" id="state_dropdown">
                                                    <option value="">State/Province</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="neighborhood" class="bmd-label-floating">City</label>
                                                <input type="text" name="city" class="form-control" placeholder="Enter City" onkeydown="return /[a-z]/i.test(event.key)" maxlength="25">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="neighborhood" class="bmd-label-floating">Zip/Postal Code</label>
                                                <input type="text" name="zip" class="form-control" placeholder="Enter Zip" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="6">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="button" class="btn btn-success" name="" value="Add Location" style="background-color: #1ED65F;border-color: #1ED65F;">
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3705.158405754491!2d72.14178991489655!3d21.77412948559929!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395f5078deacd7f7%3A0x549332d9c6ee7b65!2sTinnyPixel!5e0!3m2!1sen!2sin!4v1633528068886!5m2!1sen!2sin" width="600" allowfullscreen="" loading="lazy" class="form-control" style="border:0; height: calc(25rem + 2px);"></iframe>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Size in ft2 (*only numbers)</label>
                                                <input type="text" name="size_in_ft2" class="form-control" placeholder="Enter size in square feet" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Lot Size in ft2 (*only numbers)</label>
                                                <input type="text" name="lot_size_in_ft2" class="form-control" placeholder="Enter lot size in square feet" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Rooms (*only numbers)</label>
                                                <input type="text" name="rooms" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Enter rooms">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Bedrooms (*only numbers)</label>
                                                <input type="text" name="bedrooms" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Enter bedrooms">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Bathrooms (*only numbers)</label>
                                                <input type="text" name="bathrooms" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" placeholder="Enter bathrooms">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Custom ID (*text)</label>
                                                <input type="text" name="custom_id" class="form-control" onkeydown="return /[a-z]/i.test(event.key)" placeholder="Enter CustomId">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Year Built (*numeric)</label>
                                                <input type="text" name="year_built" class="form-control" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="4" placeholder="Enter Year built">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Garages (*text)</label>
                                                <input type="text" name="garages" class="form-control" onkeydown="return /[a-z]/i.test(event.key)" placeholder="Enter garage">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Available from (*date)</label>
                                                <input type="date" name="available_from" class="form-control" placeholder="Enter available date from">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Garage Size (*text)</label>
                                                <input type="text" name="garage_size" class="form-control" onkeydown="return /[a-z]/i.test(event.key)" placeholder="Enter garage size" maxlength="10">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">External Construction (*text)</label>
                                                <input type="text" name="external_construction" class="form-control" onkeydown="return /[a-z]/i.test(event.key)" placeholder="Enter external construction" maxlength="10">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Basement (*text)</label>
                                                <input type="text" name="basement" class="form-control" onkeydown="return /[a-z]/i.test(event.key)" placeholder="Enter basement" maxlength="10">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Exterior Material (*text)</label>
                                                <input type="text" name="exterior_material" class="form-control" onkeydown="return /[a-z]/i.test(event.key)" placeholder="Enter exterior material" maxlength="10">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="bmd-label-floating">Roofing (*text)</label>
                                                <input type="text" name="roofing" class="form-control" onkeydown="return /[a-z]/i.test(event.key)" maxlength="10" placeholder="Enter roofing">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="floors" class="bmd-label-floating">Floors No</label>
                                                {{--<input type="text" name="Construction" class="form-control">--}}
                                                <select name="floors_no" id="floors_no" class="form-control">
                                                    <option value="">Select Floors No</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="Structure" class="bmd-label-floating">Structure Type</label>
                                                {{--<input type="text" name="Construction" class="form-control">--}}
                                                <select name="structure_type" id="Structure" class="form-control">
                                                    <option value="">Select Structure Type</option>
                                                    <option value="steel">steel</option>
                                                    <option value="brick">brick</option>
                                                    <option value="vinyl">vinyl</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="bmd-label-floating" for="notes">Owner/Agent notes (*not visible on front end)</label>
                                                {{--<input type="text" name="t_description" class="form-control">--}}
                                                <textarea name="owner_agent_note" id="notes" cols="96" rows="2" class="form-control" placeholder="Enter notes"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="Structure" class="bmd-label-floating">Property Status</label>
                                                {{--<input type="text" name="Construction" class="form-control">--}}
                                                <select name="property_status" id="Structure" class="form-control">
                                                    <option value="">Select Property Status</option>
                                                    <option value="normal">normal</option>
                                                    <option value="open house">open house</option>
                                                    <option value="sold">sold</option>
                                                    <option value="new offer">new offer</option>
                                                    <option value="hot offer">hot offer</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="agent" class="bmd-label-floating">Agent</label>
                                                {{--<input type="text" name="Construction" class="form-control">--}}
                                                <select name="agent" id="agent" class="form-control">
                                                    <option value="">Select Agent</option>
                                                    @foreach($agentData as $agentDetail)
                                                    <option value="{{$agentDetail->id}}">{{$agentDetail->fullName}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                            <div class="col-md-4">
                                                <label>Amenities</label>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="form-group">
                                                    <div class="row">
                                                        @foreach($checkBoxValue as $dataValue)
                                                            <div class="col-md-4">
                                                                <div class="form-group">
                                                                    <input type="checkbox" name="amenities[]" value="{{$dataValue->id}}">&nbsp;{{$dataValue->name}}
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="Video">Video from </label>
                                                <select name="video_from" id="Video" class="form-control">
                                                    <option value="">Select Video</option>
                                                    <option value="vimeo">Vimeo</option>
                                                    <option value="youtube">Youtube </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="Video">Embed Video id:</label>
                                                <input type="text" id="Video" name="embed_video_id" class="form-control" placeholder="Enter video id">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.card-body -->
                                <div class="card-footer">
                                    <button type="submit" class="btn btn-primary" style="background-color: #1ED65F;border-color: #1ED65F;">Save</button>
                                    <a href="{{url('/admin/list-pre-construct-property')}}" class="btn btn-default" style="background-color: #949496;border-color: #949496;color: white">Back</a>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                    <!--/.col (left) -->
                </div>
                <!-- /.row -->
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    @section('script')
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <!-- add/delete-media using ajax with preview -->
        <script>
            /*$.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });*/
            $(document).on('change', '#mediaBtn',function(e) {
                let postData = new FormData();
                postData.append('file',this.files[0]);
                postData.append('_token', "{{ csrf_token() }}");
                //console.log(postData);
                $.ajax({
                    async:true,
                    type        :'post',
                    url         : "{{ url('/admin/add-pre-construct-media')}}",
                    data        : postData,
                    cache       : false,
                    contentType : false,
                    processData : false,
                    success     : function(result) {
                        //console.log(result);
                        if(result.code == 200) {
                            let url;
                            let file;

                            //if user select pdf file than preview pdf-icon image, if not than preview imageFile
                            if(result.data.media_type === 'pdf') {
                                //pdfFile preview
                                url = "{{asset('pdf-icon/pdf-logo.png')}}";
                                file = "<img class='img-responsive' src='"+url+"' height='100px' width='100px' id='del_img_"+result.data.id+"'>";
                                //success-message
                                $("#file_upload_message").empty().append(result.message).show();
                                $("#file_upload_delete").empty().append(result.message).hide();
                                $("#file_upload_error").empty().append(result.message).hide();

                            } else {
                                //imageFile preview
                                url = "{{asset('admin-panel/assets/property-images/media-file/pre-construct')}}" + "/" +result.data.media_name;
                                file = "<img class='img-responsive' src='"+url+"' height='100px' width='100px' id='del_img_"+result.data.id+"'>";
                                //success-message
                                $("#file_upload_message").empty().append(result.message).show();
                                $("#file_upload_delete").empty().append(result.message).hide();
                                $("#file_upload_error").empty().append(result.message).hide();
                            }

                            $('#image_preview').append(
                                "<input type='hidden' id='session_key_"+result.data.id+"' value='"+result.data.session_key+"'>"+
                                "<div class='image' id='img-remove_"+result.data.id+"'>" +
                                file +
                                "<br>" +
                                "<button data-id='"+result.data.id+"' type='button' class='btn btn-danger btn-sm' id='delete_btn' style='margin-top:10px; margin-left: 30px;'><i class='fa fa-trash'></i></button>" +
                                "</div>"
                            );
                        } else {
                            $("#file_upload_error").empty().append(result.message).show();
                            $("#file_upload_message").empty().append(result.message).hide();
                            $('#file_upload_delete').empty().append(result.message).hide();
                        }
                    },
                    error   : function(result) {
                        //alert(result.statusText);
                        console.log(result);
                    }
                });
            });
            $(document).on("click","#delete_btn",function (e) {
                e.preventDefault();
                if(confirm("Are you sure you want to remove this image?")){
                    let image_id = $(this).attr('data-id');
                    // let file = "<img class='img-responsive' src='"+url+"' height='100px' width='100px'>";
                    //console.log(image_id);
                    $.ajax({
                        url : "{{url('/admin/destroy-pre-construct-media')}}",
                        type : "post",
                        data : { "_token": "{{ csrf_token() }}",image_id : image_id,session_key: $("#session_key_"+image_id).val()},
                        success : function (data) {
                            //alert(image_id);
                            let url = "{{asset('admin-panel/assets/property-images/media-file/pre-construct')}}" + "/" +data.media_name;
                            let file = "<img class='img-responsive' src='"+url+"' height='100px' width='100px'>";
                            if(data.code == 200){
                                $('#img-remove_' + image_id).hide();
                                $('#file_upload_delete').empty().append(data.message).show();
                                $("#file_upload_message").empty().append(data.message).hide();
                                $("#file_upload_error").empty().append(data.message).hide();
                            }
                        }
                    });
                }
            });
        </script>
    @endsection
<script>
    function showPreview(event) {
        if(event.target.files.length > 0){
            var src = URL.createObjectURL(event.target.files[0]);
            var preview = document.getElementById("btnFloor2D-preview");
            preview.src = src;
            // preview.style.display = "block";
        }
    }
    function showPreview2(event) {
        if(event.target.files.length > 0){
            var src = URL.createObjectURL(event.target.files[0]);
            var preview2 = document.getElementById("btnFloor3D-preview");
            preview2.src = src;
            // preview.style.display = "block";
        }
    }
</script>
<script src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
<script>
    $(document).ready(function () {
        $("#btnFloor2D").click(function () {
            $('.img2D').show();
        });
        $("#btnFloor3D").click(function () {
            $('.img3D').show();
        });
    });
</script>
<!-- begin dynamic dependent dropdown country-state -->
<script>
    $(document).ready(function() {
        $('#country-dropdown').on('change', function() {
            var country_id = this.value;
            //console.log(country_id);
            $("#state_dropdown").html('');
            $.ajax({
                url:"{{url('get-states-by-country')}}",
                type: "POST",
                data: {
                    country_id: country_id,
                    _token: '{{csrf_token()}}'
                },
                dataType : 'json',
                success: function(result){
                    $("#state_dropdown").empty();
                    // $('#state_dropdown').html('<option value="">Select State</option>');
                    $.each(result.states,function(key,value){
                        $("#state_dropdown").append('<option value="'+value.id+'">'+value.name+'</option>');
                    });
                    // $('#city-dropdown').html('<option value="">Select State First</option>');
                }
            });
        });
    });
</script>
<!-- end dynamic dependent dropdown country-state -->
@endsection

